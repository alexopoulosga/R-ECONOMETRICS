# Econometrics-with-R
In this course, we will introduce coding concepts in R, and hands on hands experience with
econometric techiques. The broom, tidyverse, and ggplot package will be used in the practical exercises. In this folder, codes, labs, and data are available for your own perusal and practice.
All materials are available on my GitHub page.
